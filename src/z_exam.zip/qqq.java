package z_exam;

public class qqq {

	public static void main(String[] args) {
		

	}

}
